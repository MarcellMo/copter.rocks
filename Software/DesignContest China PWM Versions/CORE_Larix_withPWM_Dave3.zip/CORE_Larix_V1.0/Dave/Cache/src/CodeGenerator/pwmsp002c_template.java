package CodeGenerator;

import java.util.*;
import com.ifx.davex.appjetinteract.App2JetInterface;

public class pwmsp002c_template
{
  protected static String nl;
  public static synchronized pwmsp002c_template create(String lineSeparator)
  {
    nl = lineSeparator;
    pwmsp002c_template result = new pwmsp002c_template();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = NL + "/*CODE_BLOCK_BEGIN[PWMSP002.c]*/" + NL + "" + NL + "/*******************************************************************************" + NL + " Copyright (c) 2014, Infineon Technologies AG                                 **" + NL + " All rights reserved.                                                         **" + NL + "                                                                              **" + NL + " Redistribution and use in source and binary forms, with or without           **" + NL + " modification,are permitted provided that the following conditions are met:   **" + NL + "                                                                              **" + NL + " *Redistributions of source code must retain the above copyright notice,      **" + NL + " this list of conditions and the following disclaimer.                        **" + NL + " *Redistributions in binary form must reproduce the above copyright notice,   **" + NL + " this list of conditions and the following disclaimer in the documentation    **" + NL + " and/or other materials provided with the distribution.                       **" + NL + " *Neither the name of the copyright holders nor the names of its contributors **" + NL + " may be used to endorse or promote products derived from this software without**" + NL + " specific prior written permission.                                           **" + NL + "                                                                              **" + NL + " THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS \"AS IS\"  **" + NL + " AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE    **" + NL + " IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE   **" + NL + " ARE  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE   **" + NL + " LIABLE  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR         **" + NL + " CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF         **" + NL + " SUBSTITUTE GOODS OR  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS    **" + NL + " INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN      **" + NL + " CONTRACT, STRICT LIABILITY,OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)       **" + NL + " ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE   **" + NL + " POSSIBILITY OF SUCH DAMAGE.                                                  **" + NL + "                                                                              **" + NL + " To improve the quality of the software, users are encouraged to share        **" + NL + " modifications, enhancements or bug fixes with Infineon Technologies AG       **" + NL + " dave@infineon.com).                                                          **" + NL + "                                                                              **" + NL + "********************************************************************************" + NL + "**                                                                            **" + NL + "**                                                                            **" + NL + "** PLATFORM : Infineon XMC4000/XMC1000 Series                                 **" + NL + "**                                                                            **" + NL + "** COMPILER : Compiler Independent                                            **" + NL + "**                                                                            **" + NL + "** AUTHOR   : DAVE App Developer                                              **" + NL + "**                                                                            **" + NL + "** MAY BE CHANGED BY USER [yes/no]: Yes                                       **" + NL + "**                                                                            **" + NL + "** MODIFICATION DATE : April 29, 2014                                         **" + NL + "**                                                                            **" + NL + "*******************************************************************************/" + NL + "/*******************************************************************************" + NL + "**                      Author(s) Identity                                    **" + NL + "********************************************************************************" + NL + "**                                                                            **" + NL + "** Initials     Name                                                          **" + NL + "** ---------------------------------------------------------------------------**" + NL + "** KS           DAVE App Developer                                            **" + NL + "**                                                                            **" + NL + "*******************************************************************************/" + NL + "" + NL + "/**" + NL + " * @file  PWMSP002.c" + NL + " *" + NL + " * @brief This file contains implementations of all Public and Private functions" + NL + " *        of CCU8_PWMSinglePhaseDT_PWMSP002 APP." + NL + " */" + NL + "" + NL + "/* Revision History" + NL + " *  1 Dec 2012   v1.0.16   taken as base version" + NL + " * 21 Jan 2013   v1.0.18   IOCR register setting is removed since it will be " + NL + " *                         done by MUX file" + NL + " * 01 Feb 2013   v1.0.20   Constraints for PDR registers are added" + NL + " * 22 Apr 2013   v1.0.22   Open Drain Code generation updation\t" + NL + " * 31 May 2013   v1.0.24   revert to include the dave3 file only" + NL + " * 17 Feb 2014   v1.0.32   Error codes are added in various functions, that can " + NL + " *                         be logged with DBG002 App." + NL + " * 29 Apr 2014   v1.0.34   Removed the DBG002_FUNCTION_ENTRY() and " + NL + " *                         DBG002_FUNCTION_EXIT() from all the APIs.         " + NL + " *                         In PWMSP002_SetCompare() API condition checks are " + NL + " *                         added for input compare value. " + NL + " */" + NL + "" + NL + "/*******************************************************************************" + NL + "**                      Include Files                                         **" + NL + "*******************************************************************************/" + NL + "#include <DAVE3.h>" + NL + "/**" + NL + " * @cond INTERNAL_DOCS" + NL + " */" + NL + "#define APP_GID DBG002_GID_PWMSP002" + NL + "" + NL + "#define PWMSP002_STATUS_LEN 4U";
  protected final String TEXT_2 = NL;
  protected final String TEXT_3 = "  " + NL + "/*****************************************************************************" + NL + "              DUMMY DEFINTIONS OF DEBUG LOG MACROS" + NL + "*****************************************************************************/" + NL + "/*These definitions are included here to avoid compilation errors," + NL + " since the DBG002 app is not part of the project. All the macros are defined" + NL + " as empty*/ " + NL + "#ifndef _DBG002_H_" + NL + "" + NL + "#define DBG002_RegisterCallBack(A,B,C)" + NL + "#define DBG002_I(e) " + NL + "#define DBG002_IG(e,g) " + NL + "#define DBG002_IH(e,h) " + NL + "#define DBG002_IP(e,p) " + NL + "#define DBG002_IGH(e,g,h) " + NL + "#define DBG002_IGP(e,g,p) " + NL + "#define DBG002_IHP(e,h,p) " + NL + "#define DBG002_IGHP(e,g,h,p) " + NL + "#define DBG002_N(e) " + NL + "#define DBG002_NG(e,g) " + NL + "#define DBG002_NH(e,h) " + NL + "#define DBG002_NP(e,p) " + NL + "#define DBG002_NGH(e,g,h) " + NL + "#define DBG002_NGP(e,g,p) " + NL + "#define DBG002_NHP(e,h,p) " + NL + "#define DBG002_NGHP(e,g,h,p) " + NL + "#define DBG002_ID(e) " + NL + "#define DBG002_IS(e) " + NL + "#define DBG002_ISG(e,g) " + NL + "#define DBG002_SAFETY_CRITICAL(groupid,messageid,length,value)" + NL + "#define DBG002_CRITICAL(groupid,messageid,length,value)" + NL + "#define DBG002_INFO(groupid,messageid,length,value)" + NL + "#define DBG002_WARNING(groupid,messageid,length,value)" + NL + "#define DBG002_INFO(groupid,messageid,length,value)" + NL + "#define DBG002_TRACE(groupid,messageid,length,value)" + NL + "#define DBG002_FUNCTION_ENTRY(GID, Status) " + NL + "#define DBG002_FUNCTION_EXIT(GID, Status) " + NL + "#define DBG002_MESSAGEID_LITERAL " + NL + "" + NL + "#endif/* End of defintions of dummy Debug Log macros*/";
  protected final String TEXT_4 = NL + "/**" + NL + "  * @ingroup PWMSP002_privatefunc" + NL + "  * @{" + NL + "  */" + NL + "/*******************************************************************************" + NL + "**                Private Function declarations                               **" + NL + "*******************************************************************************/" + NL + "/*******************************************************************************" + NL + "**                Private Function declarations                               **" + NL + "*******************************************************************************/" + NL + "/**" + NL + " * @}" + NL + " */" + NL + "" + NL + "" + NL + "/*******************************************************************************" + NL + "**                 Function definitions                                       **" + NL + "*******************************************************************************/";
  protected final String TEXT_5 = NL;
  protected final String TEXT_6 = "   ";
  protected final String TEXT_7 = NL;
  protected final String TEXT_8 = NL + NL + "void PWMSP002_Init(void)" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "  /* CCU8 global init to start the prescalar and de-assert the module */" + NL + "  CCU8GLOBAL_Init();";
  protected final String TEXT_9 = NL + "  Status = CCU8PWMLIB_Init((const CCU8PWMLIB_HandleType*) &PWMSP002_Handle";
  protected final String TEXT_10 = ");" + NL + "  PWMSP002_Handle";
  protected final String TEXT_11 = ".DynamicHandleType->State = PWMSP002_INITIALIZED;" + NL + "  if(Status == (uint32_t)DAVEApp_SUCCESS)" + NL + "  {" + NL + "    if (PWMSP002_Handle";
  protected final String TEXT_12 = ".StartControl == (uint8_t)SET)" + NL + "    {" + NL + "      Status = PWMSP002_Start((PWMSP002_HandleType*) &PWMSP002_Handle";
  protected final String TEXT_13 = ");" + NL + "    }" + NL + "  }" + NL + "  else" + NL + "  {" + NL + "     DBG002_TRACE(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "                                              PWMSP002_STATUS_LEN, &Status);" + NL + "  }";
  protected final String TEXT_14 = NL + "    ";
  protected final String TEXT_15 = NL + "      /* Configuration of Direct Output Pin ";
  protected final String TEXT_16 = ".";
  protected final String TEXT_17 = " based on User configuration */";
  protected final String TEXT_18 = NL + "    PORT";
  protected final String TEXT_19 = "->PDR0  &= (~((uint32_t)PORT";
  protected final String TEXT_20 = "_PDR0_PD";
  protected final String TEXT_21 = "_Msk));" + NL + "    PORT";
  protected final String TEXT_22 = "->PDR0  |= (((uint32_t)";
  protected final String TEXT_23 = "U << (uint32_t)PORT";
  protected final String TEXT_24 = "_PDR0_PD";
  protected final String TEXT_25 = "_Pos) & \\" + NL + "                               (uint32_t)PORT";
  protected final String TEXT_26 = "_PDR0_PD";
  protected final String TEXT_27 = "_Msk);";
  protected final String TEXT_28 = NL + "    PORT";
  protected final String TEXT_29 = "->PDR1 &= (~((uint32_t)PORT";
  protected final String TEXT_30 = "_PDR1_PD";
  protected final String TEXT_31 = "_Msk));" + NL + "    PORT";
  protected final String TEXT_32 = "->PDR1 |= (((uint32_t)";
  protected final String TEXT_33 = "U << (uint32_t)PORT";
  protected final String TEXT_34 = "_PDR1_PD";
  protected final String TEXT_35 = "_Pos) & \\" + NL + "                               (uint32_t)PORT";
  protected final String TEXT_36 = "_PDR1_PD";
  protected final String TEXT_37 = "_Msk);";
  protected final String TEXT_38 = NL + "    PORT";
  protected final String TEXT_39 = "->IOCR0  &= (~((uint32_t)PORT_IOCR_PC";
  protected final String TEXT_40 = "_PO_Msk));" + NL + "    PORT";
  protected final String TEXT_41 = "->IOCR0  |= (((uint32_t)";
  protected final String TEXT_42 = "U << (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_43 = "_PO_Pos) & \\" + NL + "                               (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_44 = "_PO_Msk);";
  protected final String TEXT_45 = NL + "    PORT";
  protected final String TEXT_46 = "->IOCR4  &= (~((uint32_t)PORT_IOCR_PC";
  protected final String TEXT_47 = "_PO_Msk));" + NL + "    PORT";
  protected final String TEXT_48 = "->IOCR4  |= (((uint32_t)";
  protected final String TEXT_49 = "U << (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_50 = "_PO_Pos) & \\" + NL + "                               (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_51 = "_PO_Msk);";
  protected final String TEXT_52 = NL + "    PORT";
  protected final String TEXT_53 = "->IOCR8  &= (~((uint32_t)PORT_IOCR_PC";
  protected final String TEXT_54 = "_PO_Msk));" + NL + "    PORT";
  protected final String TEXT_55 = "->IOCR8  |= (((uint32_t)";
  protected final String TEXT_56 = "U << (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_57 = "_PO_Pos) & \\" + NL + "                               (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_58 = "_PO_Msk);";
  protected final String TEXT_59 = NL + "    PORT";
  protected final String TEXT_60 = "->IOCR12  &= (~((uint32_t)PORT_IOCR_PC";
  protected final String TEXT_61 = "_PO_Msk));" + NL + "    PORT";
  protected final String TEXT_62 = "->IOCR12  |= (((uint32_t)";
  protected final String TEXT_63 = "U << (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_64 = "_PO_Pos) & \\" + NL + "                               (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_65 = "_PO_Msk);";
  protected final String TEXT_66 = NL + "      /* Direct Output Pin instance (no.";
  protected final String TEXT_67 = ") is not mapped to any port pin. */";
  protected final String TEXT_68 = NL + "    ";
  protected final String TEXT_69 = "  " + NL + "    /* Configuration of Inverted Output Pin ";
  protected final String TEXT_70 = ".";
  protected final String TEXT_71 = " based on User configuration */";
  protected final String TEXT_72 = NL + "    PORT";
  protected final String TEXT_73 = "->PDR0  &= (~((uint32_t)PORT";
  protected final String TEXT_74 = "_PDR0_PD";
  protected final String TEXT_75 = "_Msk));" + NL + "    PORT";
  protected final String TEXT_76 = "->PDR0  |= (((uint32_t)";
  protected final String TEXT_77 = "U << (uint32_t)PORT";
  protected final String TEXT_78 = "_PDR0_PD";
  protected final String TEXT_79 = "_Pos) & \\" + NL + "                               (uint32_t)PORT";
  protected final String TEXT_80 = "_PDR0_PD";
  protected final String TEXT_81 = "_Msk);";
  protected final String TEXT_82 = NL + "    PORT";
  protected final String TEXT_83 = "->PDR1 &= (~((uint32_t)PORT";
  protected final String TEXT_84 = "_PDR1_PD";
  protected final String TEXT_85 = "_Msk));" + NL + "    PORT";
  protected final String TEXT_86 = "->PDR1 |= (((uint32_t)";
  protected final String TEXT_87 = "U << (uint32_t)PORT";
  protected final String TEXT_88 = "_PDR1_PD";
  protected final String TEXT_89 = "_Pos) & \\" + NL + "                               (uint32_t)PORT";
  protected final String TEXT_90 = "_PDR1_PD";
  protected final String TEXT_91 = "_Msk);";
  protected final String TEXT_92 = NL + "    PORT";
  protected final String TEXT_93 = "->IOCR0  &= (~((uint32_t)PORT_IOCR_PC";
  protected final String TEXT_94 = "_PO_Msk));" + NL + "    PORT";
  protected final String TEXT_95 = "->IOCR0  |= (((uint32_t)";
  protected final String TEXT_96 = "U << (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_97 = "_PO_Pos) & \\" + NL + "                              (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_98 = "_PO_Msk);";
  protected final String TEXT_99 = NL + "    PORT";
  protected final String TEXT_100 = "->IOCR4  &= (~((uint32_t)PORT_IOCR_PC";
  protected final String TEXT_101 = "_PO_Msk));" + NL + "    PORT";
  protected final String TEXT_102 = "->IOCR4  |= (((uint32_t)";
  protected final String TEXT_103 = "U << (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_104 = "_PO_Pos) & \\" + NL + "                              (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_105 = "_PO_Msk);";
  protected final String TEXT_106 = NL + "    PORT";
  protected final String TEXT_107 = "->IOCR8  &= (~((uint32_t)PORT_IOCR_PC";
  protected final String TEXT_108 = "_PO_Msk));" + NL + "    PORT";
  protected final String TEXT_109 = "->IOCR8  |= (((uint32_t)";
  protected final String TEXT_110 = "U << (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_111 = "_PO_Pos) & \\" + NL + "                              (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_112 = "_PO_Msk);";
  protected final String TEXT_113 = NL + "    PORT";
  protected final String TEXT_114 = "->IOCR12  &= (~((uint32_t)PORT_IOCR_PC";
  protected final String TEXT_115 = "_PO_Msk));" + NL + "    PORT";
  protected final String TEXT_116 = "->IOCR12  |= (((uint32_t)";
  protected final String TEXT_117 = "U << (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_118 = "_PO_Pos) & \\" + NL + "                              (uint32_t)PORT_IOCR_PC";
  protected final String TEXT_119 = "_PO_Msk);";
  protected final String TEXT_120 = NL + "      /* Inverted Output Pin instance (no.";
  protected final String TEXT_121 = ") is not mapped to any port pin. */";
  protected final String TEXT_122 = NL + "}" + NL + "" + NL + "/*<<<DD_PWMSP002_API_2>>>*/" + NL + "/**" + NL + " * This function resets the app and the CCU8x_CC8y slice" + NL + " */" + NL + "status_t PWMSP002_Deinit(const PWMSP002_HandleType* HandlePtr)" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "/*<<<DD_PWMSP002_API_2_1>>>*/" + NL + "  if (HandlePtr->DynamicHandleType->State == PWMSP002_UNINITIALIZED)" + NL + "  {" + NL + "    DBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "    \t\t\t                                  PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "  else" + NL + "  {" + NL + "    Status = CCU8PWMLIB_Deinit((const CCU8PWMLIB_HandleType*)HandlePtr);" + NL + "    HandlePtr->DynamicHandleType->State = PWMSP002_UNINITIALIZED;" + NL + "  }" + NL + "  return Status;" + NL + "}" + NL + "" + NL + "/*<<<DD_PWMSP002_API_3>>>*/" + NL + "/**" + NL + " * This function starts the app and sets the run bit of the timer" + NL + " */" + NL + "status_t PWMSP002_Start(const PWMSP002_HandleType* HandlePtr)" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "" + NL + "/*<<<DD_PWMSP002_API_3_1>>>*/" + NL + "  if ((HandlePtr->DynamicHandleType->State != PWMSP002_INITIALIZED) &&" + NL + "      (HandlePtr->DynamicHandleType->State != PWMSP002_STOPPED))" + NL + "  {" + NL + "\t DBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t    \t\t\t                              PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "  else" + NL + "  {" + NL + "    Status = CCU8PWMLIB_Start((const CCU8PWMLIB_HandleType*)HandlePtr);" + NL + "    HandlePtr->DynamicHandleType->State = PWMSP002_RUNNING;" + NL + "  }" + NL + "  return Status;" + NL + "}" + NL + "" + NL + "/*<<<DD_PWMSP002_API_4>>>*/" + NL + "/**" + NL + " * This function stops the app and the timer" + NL + " */" + NL + "status_t PWMSP002_Stop(const PWMSP002_HandleType* HandlePtr)" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "" + NL + "/*<<<DD_PWMSP002_API_4_1>>>*/" + NL + "" + NL + "  if ((HandlePtr->DynamicHandleType->State != PWMSP002_RUNNING))" + NL + "  {" + NL + "     DBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "/*<<<DD_PWMSP002_API_4_3>>>*/" + NL + "  else" + NL + "  {" + NL + "    Status = CCU8PWMLIB_Stop((const CCU8PWMLIB_HandleType*)HandlePtr);" + NL + "    HandlePtr->DynamicHandleType->State = PWMSP002_STOPPED;" + NL + "" + NL + "  }" + NL + "  return Status;" + NL + " }" + NL + "" + NL + "/*<<<DD_PWMSP002_API_5>>>*/" + NL + "/**" + NL + " * This function changes the duty cycle of the PWM waveform by changing the" + NL + " * compare register value." + NL + " * Sign = 0: Compare value is incremented by shift. This is not allowed in edge-aligned." + NL + " * Sign = 1: Compare value is decremented by shift." + NL + " */" + NL + "status_t PWMSP002_SetCompare" + NL + "(" + NL + "  const PWMSP002_HandleType* HandlePtr," + NL + "  uint32_t Compare1," + NL + "  uint32_t Compare2" + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "" + NL + "/*<<<DD_PWMSP002_API_5_1>>>*/" + NL + "    if ((HandlePtr->DynamicHandleType->State == PWMSP002_UNINITIALIZED))" + NL + "    {" + NL + "   \t DBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "   \t    \t\t\t                              PWMSP002_STATUS_LEN, &Status);" + NL + "    }" + NL + "/*<<<DD_PWMSP002_API_5_2>>>*/" + NL + "    else if((Compare1 > CCU8PWMLIB_MAX_VALUE) &&" + NL + "            (HandlePtr->kTimerConcatenation == (uint8_t)RESET))" + NL + "    {" + NL + "    \tStatus = (uint32_t)PWMSP002_INVALID_PARAM_ERROR;" + NL + "    }" + NL + "/*<<<DD_PWMSP002_API_5_3>>>*/" + NL + "    /* Call the function as per configured mode */" + NL + "    else" + NL + "    {" + NL + "    Status = HandlePtr->SetCompareFuncPtr((const void*)HandlePtr, Compare1, Compare2);" + NL + "    } " + NL + "  return Status;" + NL + "}" + NL + "" + NL + "" + NL + "/**" + NL + " * This function changes the duty cycle of the app." + NL + " * Sign = 0: Compare value is incremented by shift. This is not allowed in edge-aligned." + NL + " * Sign = 1: Compare value is decremented by shift." + NL + " */" + NL + "status_t PWMSP002_SetDutyCycle" + NL + "(" + NL + "  const PWMSP002_HandleType* HandlePtr," + NL + "  float DutyCycle," + NL + "  uint32_t Shift," + NL + "  uint8_t Sign" + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "  /*<<<DD_PWMSP002_API_15_1>>>*/" + NL + "  if (HandlePtr->DynamicHandleType->State != PWMSP002_UNINITIALIZED)" + NL + "  {" + NL + "    /*<<<DD_PWMSP002_API_15_2>>>*/" + NL + "    /* duty cycle has to be in between 0 and 100 */" + NL + "    if ( (DutyCycle > (float)100.0) || (DutyCycle < (float)0.0))" + NL + "    {" + NL + "      Status = (uint32_t)PWMSP002_INVALID_PARAM_ERROR;" + NL + "    }" + NL + "    else" + NL + "    {" + NL + "    " + NL + "      /* Call the function as per configured mode */" + NL + "      Status = HandlePtr->SetDutyFuncPtr((const void*)HandlePtr, DutyCycle, Shift, Sign);" + NL + "    }" + NL + "  }" + NL + "  return Status;" + NL + "}" + NL + "" + NL + "/** This function changes the PWM frequency and duty cycle */" + NL + "status_t PWMSP002_SetPeriodAndCompare" + NL + "(" + NL + "  const PWMSP002_HandleType* HandlePtr," + NL + "  uint32_t PwmFreq," + NL + "  uint32_t Compare1," + NL + "  uint32_t Compare2  " + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "  if ((HandlePtr->DynamicHandleType->State != PWMSP002_UNINITIALIZED))" + NL + "  {" + NL + "/*<<<DD_PWMSP002_API_6_1>>>*/" + NL + " /* Frequency can be changed only when timer is not running */" + NL + "    if(PwmFreq == (uint32_t)RESET)" + NL + "    {" + NL + "      Status  = (uint32_t)PWMSP002_INVALID_PARAM_ERROR;" + NL + "    }" + NL + "    else" + NL + "    {" + NL + "      Status = CCU8PWMLIB_SetPeriod((const CCU8PWMLIB_HandleType*)HandlePtr, PwmFreq);" + NL + "      Status = HandlePtr->SetCompareFuncPtr((const void*)HandlePtr, Compare1, Compare2);" + NL + "    }" + NL + "  }" + NL + "  if (Status != (uint32_t)DAVEApp_SUCCESS)" + NL + "  {" + NL + "\tDBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "  return Status;" + NL + "}" + NL + "" + NL + "/*<<<DD_PWMSP002_API_6>>>*/" + NL + "/** This function changes the PWM frequency */" + NL + "status_t PWMSP002_SetPeriod" + NL + "(" + NL + "  const PWMSP002_HandleType* HandlePtr," + NL + "  uint32_t PwmFreq" + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "  if ((HandlePtr->DynamicHandleType->State != PWMSP002_UNINITIALIZED))" + NL + "  {" + NL + "    /*<<<DD_PWMSP002_API_6_1>>>*/" + NL + "    /* Frequency can be changed only when timer is not running */" + NL + "    " + NL + "    if(PwmFreq == (uint32_t)RESET)" + NL + "    {" + NL + "      Status  = (uint32_t)PWMSP002_INVALID_PARAM_ERROR;" + NL + "    }" + NL + "    else" + NL + "    {" + NL + "      Status = CCU8PWMLIB_SetPeriod((const CCU8PWMLIB_HandleType*)HandlePtr, PwmFreq);" + NL + "    }" + NL + "  }" + NL + "  if (Status != (uint32_t)DAVEApp_SUCCESS)" + NL + "  {" + NL + "\tDBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "  return Status;" + NL + "}" + NL + "" + NL + "" + NL + "/* This function changes the PWM frequency and duty cycle */" + NL + "status_t PWMSP002_SetPwmFreqAndDutyCycle" + NL + "(" + NL + "  const PWMSP002_HandleType* HandlePtr," + NL + "  float PwmFreq," + NL + "  float DutyCycle," + NL + "  uint32_t Shift," + NL + "  uint8_t Sign  " + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "  if(HandlePtr->DynamicHandleType->State != PWMSP002_UNINITIALIZED)" + NL + "  {" + NL + "/*<<<DD_PWMSP002_API_16_1>>>*/" + NL + "    /* Frequency can be changed only when timer is not running */" + NL + "    " + NL + "    if((PwmFreq == (float)0.0) || (DutyCycle > (float)100.0) || (DutyCycle < (float)0.0))" + NL + "    {" + NL + "      Status = (uint32_t)PWMSP002_INVALID_PARAM_ERROR;" + NL + "    }" + NL + "    else" + NL + "    {" + NL + "      Status = CCU8PWMLIB_SetPwmFreq((const CCU8PWMLIB_HandleType*)HandlePtr, PwmFreq);" + NL + "      Status = HandlePtr->SetDutyFuncPtr((const void*)HandlePtr, DutyCycle, Shift, Sign);" + NL + "    }" + NL + "  }" + NL + "  return Status;" + NL + "}" + NL + "" + NL + "/*<<<DD_PWMSP002_API_16>>>*/" + NL + "/* This function changes the PWM frequency */" + NL + "status_t PWMSP002_SetPwmFreq" + NL + "(" + NL + "  const PWMSP002_HandleType* HandlePtr," + NL + "  float PwmFreq" + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "  if(HandlePtr->DynamicHandleType->State != PWMSP002_UNINITIALIZED)" + NL + "  {" + NL + "    /*<<<DD_PWMSP002_API_16_1>>>*/" + NL + "    /* Frequency can be changed only when timer is not running */" + NL + "    if(PwmFreq == (float)0.0)" + NL + "    {" + NL + "      Status = (uint32_t)PWMSP002_INVALID_PARAM_ERROR;" + NL + " \t  DBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + " \t    \t\t\t                              PWMSP002_STATUS_LEN, &Status);" + NL + "    }" + NL + "    else" + NL + "    {" + NL + "      Status = CCU8PWMLIB_SetPwmFreq((const CCU8PWMLIB_HandleType*)HandlePtr, PwmFreq);" + NL + "    }" + NL + "  }" + NL + "  return Status;" + NL + "}" + NL + "" + NL + "/*<<<DD_PWMSP002_API_7>>*/" + NL + "/**" + NL + " * This function sets the timer value when timer is not running" + NL + " */" + NL + "status_t PWMSP002_SetTimerVal" + NL + "(" + NL + "  const PWMSP002_HandleType* HandlePtr," + NL + "  uint32_t TimerVal" + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "/*<<<DD_PWMSP002_API_7_1>>*/" + NL + "  if ((HandlePtr->DynamicHandleType->State == PWMSP002_RUNNING) ||" + NL + "        (HandlePtr->DynamicHandleType->State == PWMSP002_UNINITIALIZED))" + NL + "  {" + NL + "\tDBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "/*<<<DD_PWMSP002_API_7_2>>*/" + NL + "  else" + NL + "  {" + NL + "    Status = CCU8PWMLIB_SetTimerVal((const CCU8PWMLIB_HandleType*)HandlePtr, TimerVal);" + NL + "  }" + NL + "  return Status;" + NL + "}" + NL + "/*<<<DD_PWMSP002_API_8>>*/" + NL + "/**" + NL + " * This function reads the timer status" + NL + " */" + NL + "status_t PWMSP002_GetTimerStatus" + NL + "(" + NL + " const PWMSP002_HandleType* HandlePtr," + NL + " uint32_t* TimerStatusPtr" + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "/*<<<DD_PWMSP002_API_8_1>>>*/" + NL + "  if ((HandlePtr->DynamicHandleType->State == PWMSP002_UNINITIALIZED))" + NL + "  {" + NL + "\tDBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "/*<<<DD_PWMSP002_API_8_2>>>*/" + NL + "  else" + NL + "  {" + NL + "    Status = CCU8PWMLIB_GetTimerStatus((const CCU8PWMLIB_HandleType*)HandlePtr, TimerStatusPtr);" + NL + "  }" + NL + "  return Status;" + NL + "}" + NL + "" + NL + "/*<<<DD_PWMSP002_API_9>>*/" + NL + "/**" + NL + " * This function reads the period, compare register values." + NL + " */" + NL + "status_t PWMSP002_GetTimerRegsVal" + NL + "(" + NL + "  const PWMSP002_HandleType* HandlePtr," + NL + "  PWMSP002_TimerRegsType* TimerRegsPtr" + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "" + NL + "/*<<<DD_PWMSP002_API_9_1>>*/" + NL + "  if ((HandlePtr->DynamicHandleType->State == PWMSP002_UNINITIALIZED))" + NL + "  {" + NL + "\tDBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "  else" + NL + "  {" + NL + "    Status = CCU8PWMLIB_GetTimerRegsVal((const CCU8PWMLIB_HandleType*)HandlePtr, " + NL + "        (CCU8PWMLIB_TimerRegsType*)TimerRegsPtr); " + NL + "  }" + NL + "  return Status;" + NL + "}" + NL + "" + NL + "/*<<<DD_PWMSP002_API_15>>>*/" + NL + "/*" + NL + " * This function reads the period register value." + NL + " * This function can be used by user to calculate the compare register value" + NL + " * as per required duty cycle." + NL + " */" + NL + "status_t PWMSP002_GetPeriodReg" + NL + "(" + NL + "  const PWMSP002_HandleType* HandlePtr," + NL + "  uint32_t* PeriodRegPtr" + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "" + NL + "/*<<<DD_PWMSP002_API_15_1>>>*/" + NL + "  if ((HandlePtr->DynamicHandleType->State == PWMSP002_UNINITIALIZED))" + NL + "  {" + NL + "\tDBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "  else" + NL + "  {" + NL + "    Status = CCU8PWMLIB_GetPeriodReg((const CCU8PWMLIB_HandleType*)HandlePtr, PeriodRegPtr);" + NL + "  }" + NL + "  return Status;" + NL + "}" + NL + "" + NL + "/*<<<DD_PWMSP002_API_10>>>*/" + NL + "/**" + NL + " * This function initiates the shadow transfer of period and compare registers." + NL + " */" + NL + "status_t PWMSP002_SWRequestShadowTransfer" + NL + "(" + NL + " const PWMSP002_HandleType* HandlePtr" + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "" + NL + "/*<<<DD_PWMSP002_API_10_1>>>*/" + NL + "  if ((HandlePtr->DynamicHandleType->State == PWMSP002_UNINITIALIZED))" + NL + "  {" + NL + "\tDBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "/*<<<DD_PWMSP002_API_10_2>>>*/" + NL + "" + NL + "  else" + NL + "  {" + NL + "    Status = CCU8PWMLIB_SWRequestShadowTransfer((const CCU8PWMLIB_HandleType*)HandlePtr);" + NL + "  }" + NL + "  return Status;" + NL + "}" + NL + "" + NL + "/*<<<DD_PWMSP002_API_13>>>*/" + NL + "/**" + NL + " * This function resets the trap flag if SW exit from trap state is configured" + NL + " */" + NL + "status_t PWMSP002_ResetTrapFlag(const PWMSP002_HandleType* HandlePtr)" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "" + NL + "/*<<<DD_PWMSP002_API_13_1>>>*/" + NL;
  protected final String TEXT_123 = "  if ((HandlePtr->DynamicHandleType->State == PWMSP002_UNINITIALIZED))" + NL + "  {" + NL + "\tDBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "  /*<<<DD_PWMSP002_API_13_2>>>*/" + NL + "  else" + NL + "  {" + NL + "    Status = CCU8PWMLIB_ResetTrapFlag((const CCU8PWMLIB_HandleType*)HandlePtr);   " + NL + "  }" + NL + "  return Status;" + NL + "}" + NL + "/**" + NL + " * This function sets the enable event bit for the event given in the argument." + NL + " */" + NL + "status_t PWMSP002_EnableEvent" + NL + "(" + NL + "     const PWMSP002_HandleType * HandlePtr," + NL + "     const PWMSP002_EventNameType Event" + NL + ")" + NL + " {" + NL + "   status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "" + NL + "   if (HandlePtr->DynamicHandleType->State == PWMSP002_UNINITIALIZED)" + NL + "   {" + NL + "\t DBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "   }" + NL + "   else" + NL + "   {" + NL + "      Status = CCU8PWMLIB_EnableEvent((const CCU8PWMLIB_HandleType*)HandlePtr,(CCU8PWMLIB_EventNameType)Event);" + NL + "   }" + NL + "   return (Status);" + NL + " }" + NL + "" + NL + " /**" + NL + "  * This function clears the enable event bit for the event given in the argument." + NL + "  */" + NL + "status_t PWMSP002_DisableEvent" + NL + "(" + NL + "    const PWMSP002_HandleType * HandlePtr," + NL + "    const PWMSP002_EventNameType Event" + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "" + NL + "  if (HandlePtr->DynamicHandleType->State == PWMSP002_UNINITIALIZED)" + NL + "  {" + NL + "\tDBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "  else" + NL + "  {" + NL + "    Status = CCU8PWMLIB_DisableEvent((const CCU8PWMLIB_HandleType*)HandlePtr,(CCU8PWMLIB_EventNameType) Event);" + NL + "  }" + NL + "  return (Status);" + NL + "}" + NL + "" + NL + "/**" + NL + " * This function clears the interrupt by software." + NL + " */" + NL + "status_t PWMSP002_ClearPendingEvent" + NL + "(" + NL + "    const PWMSP002_HandleType * HandlePtr," + NL + "    const PWMSP002_EventNameType Event" + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "" + NL + "  if (HandlePtr->DynamicHandleType->State == PWMSP002_UNINITIALIZED)" + NL + "  {" + NL + "\tDBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "  else" + NL + "  {" + NL + "    Status = CCU8PWMLIB_ClearPendingEvent((const CCU8PWMLIB_HandleType*)HandlePtr, (CCU8PWMLIB_EventNameType)Event);" + NL + "  }" + NL + "  return (Status);" + NL + "}" + NL + "" + NL + "/**" + NL + " * This function sets the interrupt by software Interrupt pulse is generated" + NL + " * if source is enabled." + NL + " */" + NL + "status_t PWMSP002_SetPendingEvent" + NL + "(" + NL + "    const PWMSP002_HandleType * HandlePtr," + NL + "    const PWMSP002_EventNameType Event" + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "" + NL + "  if (HandlePtr->DynamicHandleType->State == PWMSP002_UNINITIALIZED)" + NL + "  {" + NL + "\tDBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "  else" + NL + "  {" + NL + "    Status = CCU8PWMLIB_SetPendingEvent((const CCU8PWMLIB_HandleType*)HandlePtr, (CCU8PWMLIB_EventNameType)Event);" + NL + "  }" + NL + "  return (Status);" + NL + "}" + NL + "" + NL + "/**" + NL + " * This function check whether given interrupt is set" + NL + " */" + NL + "status_t PWMSP002_GetPendingEvent" + NL + "(" + NL + "    const PWMSP002_HandleType * HandlePtr," + NL + "    const PWMSP002_EventNameType Event," + NL + "    uint8_t* EvtStatus" + NL + ")" + NL + "{" + NL + "  status_t Status = (uint32_t)PWMSP002_OPER_NOT_ALLOWED_ERROR;" + NL + "" + NL + "  if (HandlePtr->DynamicHandleType->State == PWMSP002_UNINITIALIZED)" + NL + "  {" + NL + "\tDBG002_INFO(DBG002_GID_PWMSP002, DBG002_MESSAGEID_LITERAL, \\" + NL + "\t\t    \t\t\t                          PWMSP002_STATUS_LEN, &Status);" + NL + "  }" + NL + "  else" + NL + "  {" + NL + "    Status = CCU8PWMLIB_GetPendingEvent((const CCU8PWMLIB_HandleType*)HandlePtr, (CCU8PWMLIB_EventNameType)Event, EvtStatus);" + NL + "  }" + NL + "  return (Status);" + NL + "}" + NL + "/**" + NL + " * @endcond" + NL + " */" + NL + "/*CODE_BLOCK_END*/" + NL;
  protected final String TEXT_124 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     App2JetInterface app = (App2JetInterface) argument; 
    stringBuffer.append(TEXT_1);
     String TempApps = null;
   String MyAppName = null;
   ArrayList<String> apps;
   String TempLowerApps = null; 
   boolean DBGApp = false;   
   apps=(ArrayList<String>)(app.getApps());
        for (int k = 0; k < apps.size(); k++) {
              TempApps = apps.get(k);
//            if(app.isAppInitProvider(apps.get(k)) == true) {
              MyAppName = TempApps.substring(TempApps.indexOf("/app/") + 5, TempApps.lastIndexOf("/"));
              TempLowerApps = MyAppName.toLowerCase();
              if (TempLowerApps.equalsIgnoreCase("dbg002")) {DBGApp = true;}   
//   }  
  } 
    stringBuffer.append(TEXT_2);
     if (!DBGApp) { 
    stringBuffer.append(TEXT_3);
     } 
    stringBuffer.append(TEXT_4);
     String AppBaseuri = "app/pwmsp002/"; 
     String SliceUri = null; 
     String kernelNo = null; 
     String sliceNo = null; 
     String ccu8globaluri = null; 
     String globaluri = null; 
     String globalNo = null; 
     String appInst  = null; 
    stringBuffer.append(TEXT_5);
     String P ;
     String pinUri ;
     String portNo ;
     String pinNo ;
    stringBuffer.append(TEXT_6);
     int PDR_PD1 ;
     int PDR_PO ;
     int Pin ;
    stringBuffer.append(TEXT_7);
     int Is13Device = -1; 
     Is13Device = ((app.getSoftwareId().substring(0,2).compareTo("13")==0)?1:0); 
    stringBuffer.append(TEXT_8);
     ArrayList<String> appsList = (ArrayList<String>)(app.getApps("app/pwmsp002/"));
for (String appIns : appsList ) {
appInst = appIns.substring(appIns.lastIndexOf("/")+1);
    stringBuffer.append(TEXT_9);
    stringBuffer.append( appInst);
    stringBuffer.append(TEXT_10);
    stringBuffer.append( appInst);
    stringBuffer.append(TEXT_11);
    stringBuffer.append( appInst);
    stringBuffer.append(TEXT_12);
    stringBuffer.append( appInst);
    stringBuffer.append(TEXT_13);
     if(app.getIntegerValue(AppBaseuri + appInst +"/pwmsp002_erwdirectoutputpadenable/0")==1)
     { 
     pinUri = app.getMappedUri(AppBaseuri + appInst +"/pin_directoutput"); 
     if ((pinUri != null) && (pinUri.trim() != "")) 
     { 
     portNo = pinUri.substring(pinUri.indexOf("port/p/")+7,pinUri.indexOf("/pad/")); 
     pinNo = pinUri.substring(pinUri.indexOf("/pad/")+5,pinUri.length()); 
     PDR_PD1 = app.getIntegerValue(AppBaseuri + appInst +"/pin_directoutput/pdr_pd"); 
     PDR_PO = app.getIntegerValue(AppBaseuri + appInst +"/pwmsp002_erwdirectoutputpadchar/1");
     Pin = Integer.parseInt(pinNo);
    stringBuffer.append(TEXT_14);
     if (Is13Device==0) 
     { 
    stringBuffer.append(TEXT_15);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_16);
    stringBuffer.append(pinNo);
    stringBuffer.append(TEXT_17);
     if(Pin < 8) 
     { 
    stringBuffer.append(TEXT_18);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_19);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_20);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_21);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(PDR_PD1);
    stringBuffer.append(TEXT_23);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_24);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_25);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_26);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_27);
     } else { 
    stringBuffer.append(TEXT_28);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_29);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_30);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_31);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_32);
    stringBuffer.append(PDR_PD1);
    stringBuffer.append(TEXT_33);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_34);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_35);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_36);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_37);
     } 
     } 
     if(Pin < 4) 
     { 
    stringBuffer.append(TEXT_38);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_39);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_40);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_41);
    stringBuffer.append(PDR_PO);
    stringBuffer.append(TEXT_42);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_43);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_44);
     } else  if(Pin < 8){ 
    stringBuffer.append(TEXT_45);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_46);
    stringBuffer.append(Pin - 4);
    stringBuffer.append(TEXT_47);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_48);
    stringBuffer.append(PDR_PO);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(Pin -4);
    stringBuffer.append(TEXT_50);
    stringBuffer.append(Pin -4 );
    stringBuffer.append(TEXT_51);
     } else  if(Pin < 12){ 
    stringBuffer.append(TEXT_52);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_53);
    stringBuffer.append(Pin - 8);
    stringBuffer.append(TEXT_54);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_55);
    stringBuffer.append(PDR_PO);
    stringBuffer.append(TEXT_56);
    stringBuffer.append(Pin -8);
    stringBuffer.append(TEXT_57);
    stringBuffer.append(Pin - 8 );
    stringBuffer.append(TEXT_58);
     } else { 
    stringBuffer.append(TEXT_59);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_60);
    stringBuffer.append(Pin - 12);
    stringBuffer.append(TEXT_61);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_62);
    stringBuffer.append(PDR_PO);
    stringBuffer.append(TEXT_63);
    stringBuffer.append(Pin -12);
    stringBuffer.append(TEXT_64);
    stringBuffer.append(Pin - 12 );
    stringBuffer.append(TEXT_65);
     } 
     } 
     else { 
    stringBuffer.append(TEXT_66);
    stringBuffer.append( appInst );
    stringBuffer.append(TEXT_67);
     } 
     } 
     if(app.getIntegerValue(AppBaseuri + appInst +"/pwmsp002_erwinvertedoutputpadenable/0")==1)
     { 
     pinUri = app.getMappedUri(AppBaseuri + appInst +"/pin_invertedoutput"); 
     if ((pinUri != null) && (pinUri.trim() != "")) 
     { 
     portNo = pinUri.substring(pinUri.indexOf("port/p/")+7,pinUri.indexOf("/pad/")); 
     pinNo = pinUri.substring(pinUri.indexOf("/pad/")+5,pinUri.length()); 
     PDR_PD1 = app.getIntegerValue(AppBaseuri + appInst +"/pin_invertedoutput/pdr_pd"); 
     PDR_PO = app.getIntegerValue(AppBaseuri + appInst +"/pwmsp002_erwinvertedoutputpadchar/1");
     Pin = Integer.parseInt(pinNo);
    stringBuffer.append(TEXT_68);
     if (Is13Device==0) 
     { 
    stringBuffer.append(TEXT_69);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_70);
    stringBuffer.append(pinNo);
    stringBuffer.append(TEXT_71);
     if(Pin < 8) 
     { 
    stringBuffer.append(TEXT_72);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_73);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_74);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_75);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_76);
    stringBuffer.append(PDR_PD1);
    stringBuffer.append(TEXT_77);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_78);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_79);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_80);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_81);
     } else { 
    stringBuffer.append(TEXT_82);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_83);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_84);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_85);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_86);
    stringBuffer.append(PDR_PD1);
    stringBuffer.append(TEXT_87);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_88);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_89);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_90);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_91);
     } 
     } 
     if(Pin < 4) 
     { 
    stringBuffer.append(TEXT_92);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_93);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_94);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_95);
    stringBuffer.append(PDR_PO);
    stringBuffer.append(TEXT_96);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_97);
    stringBuffer.append(Pin);
    stringBuffer.append(TEXT_98);
     } else  if(Pin < 8){ 
    stringBuffer.append(TEXT_99);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_100);
    stringBuffer.append(Pin - 4);
    stringBuffer.append(TEXT_101);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_102);
    stringBuffer.append(PDR_PO);
    stringBuffer.append(TEXT_103);
    stringBuffer.append(Pin -4);
    stringBuffer.append(TEXT_104);
    stringBuffer.append(Pin -4 );
    stringBuffer.append(TEXT_105);
     } else  if(Pin < 12){ 
    stringBuffer.append(TEXT_106);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_107);
    stringBuffer.append(Pin - 8);
    stringBuffer.append(TEXT_108);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_109);
    stringBuffer.append(PDR_PO);
    stringBuffer.append(TEXT_110);
    stringBuffer.append(Pin -8);
    stringBuffer.append(TEXT_111);
    stringBuffer.append(Pin - 8 );
    stringBuffer.append(TEXT_112);
     } else { 
    stringBuffer.append(TEXT_113);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_114);
    stringBuffer.append(Pin - 12);
    stringBuffer.append(TEXT_115);
    stringBuffer.append(portNo);
    stringBuffer.append(TEXT_116);
    stringBuffer.append(PDR_PO);
    stringBuffer.append(TEXT_117);
    stringBuffer.append(Pin -12);
    stringBuffer.append(TEXT_118);
    stringBuffer.append(Pin - 12 );
    stringBuffer.append(TEXT_119);
     } 
     } 
     else { 
    stringBuffer.append(TEXT_120);
    stringBuffer.append( appInst );
    stringBuffer.append(TEXT_121);
     } 
     } 
    }
    stringBuffer.append(TEXT_122);
    stringBuffer.append(TEXT_123);
    stringBuffer.append(TEXT_124);
    return stringBuffer.toString();
  }
}
