package CodeGenerator;

import java.util.*;
import java.text.*;
import com.ifx.davex.appjetinteract.App2JetInterface;

public class pwmsp002confc_template
{
  protected static String nl;
  public static synchronized pwmsp002confc_template create(String lineSeparator)
  {
    nl = lineSeparator;
    pwmsp002confc_template result = new pwmsp002confc_template();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = NL + "/*CODE_BLOCK_BEGIN[PWMSP002Conf.c]*/" + NL + "" + NL + "/*******************************************************************************" + NL + " Copyright (c) 2014, Infineon Technologies AG                                 **" + NL + " All rights reserved.                                                         **" + NL + "                                                                              **" + NL + " Redistribution and use in source and binary forms, with or without           **" + NL + " modification,are permitted provided that the following conditions are met:   **" + NL + "                                                                              **" + NL + " *Redistributions of source code must retain the above copyright notice,      **" + NL + " this list of conditions and the following disclaimer.                        **" + NL + " *Redistributions in binary form must reproduce the above copyright notice,   **" + NL + " this list of conditions and the following disclaimer in the documentation    **" + NL + " and/or other materials provided with the distribution.                       **" + NL + " *Neither the name of the copyright holders nor the names of its contributors **" + NL + " may be used to endorse or promote products derived from this software without**" + NL + " specific prior written permission.                                           **" + NL + "                                                                              **" + NL + " THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS \"AS IS\"  **" + NL + " AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE    **" + NL + " IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE   **" + NL + " ARE  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE   **" + NL + " LIABLE  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR         **" + NL + " CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF         **" + NL + " SUBSTITUTE GOODS OR  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS    **" + NL + " INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN      **" + NL + " CONTRACT, STRICT LIABILITY,OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)       **" + NL + " ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE   **" + NL + " POSSIBILITY OF SUCH DAMAGE.                                                  **" + NL + "                                                                              **" + NL + " To improve the quality of the software, users are encouraged to share        **" + NL + " modifications, enhancements or bug fixes with Infineon Technologies AG       **" + NL + " dave@infineon.com).                                                          **" + NL + "                                                                              **" + NL + "********************************************************************************" + NL + "**                                                                            **" + NL + "**                                                                            **" + NL + "** PLATFORM : Infineon XMC4000/XMC1000 Series                                 **" + NL + "**                                                                            **" + NL + "** COMPILER : Compiler Independent                                            **" + NL + "**                                                                            **" + NL + "** AUTHOR   : DAVE App Developer                                              **" + NL + "**                                                                            **" + NL + "** MAY BE CHANGED BY USER [yes/Yes]: Yes                                      **" + NL + "**                                                                            **" + NL + "** MODIFICATION DATE : April 29, 2014                                         **" + NL + "**                                                                            **" + NL + "*******************************************************************************/" + NL + "" + NL + "/*******************************************************************************" + NL + "**                       Author(s) Identity                                   **" + NL + "********************************************************************************" + NL + "**                                                                            **" + NL + "** Initials     Name                                                          **" + NL + "** ---------------------------------------------------------------------------**" + NL + "** KS           DAVE App Developer                                            **" + NL + "*******************************************************************************/";
  protected final String TEXT_2 = NL + "/**" + NL + " * @file  PWMSP002_Conf.c" + NL + " * @App Version <";
  protected final String TEXT_3 = ">" + NL + " * @brief This file contains App parameter data as per GUI configurations" + NL + " *" + NL + " */" + NL + "/* Revision History" + NL + " * 01 Dec 2012   v1.0.16   taken as base version" + NL + " * 29 Apr 2014   v1.0.34   During Timer Concatenation Period and compare1 values" + NL + " *                         are read from UI parameters defined for registers " + NL + " *                         individually." + NL + " */" + NL + "#include <DAVE3.h>";
  protected final String TEXT_4 = " ";
  protected final String TEXT_5 = " ";
  protected final String TEXT_6 = " ";
  protected final String TEXT_7 = NL + NL + "PWMSP002_DynamicHandleType PWMSP002_DynamicHandle";
  protected final String TEXT_8 = " =" + NL + "{" + NL + "  .State = PWMSP002_UNINITIALIZED" + NL + "};" + NL + "" + NL + "const PWMSP002_HandleType PWMSP002_Handle";
  protected final String TEXT_9 = " =" + NL + "{" + NL + "  .kTimerMode= ";
  protected final String TEXT_10 = "U,";
  protected final String TEXT_11 = NL + "  .CompareMode= CCU8PWMLIB_SYMMETRIC,";
  protected final String TEXT_12 = NL + "  .CompareMode= CCU8PWMLIB_ASYMMETRIC,";
  protected final String TEXT_13 = NL + "  .CountingMode= CCU8PWMLIB_EDGE_ALIGNED,";
  protected final String TEXT_14 = NL + "  .CountingMode= CCU8PWMLIB_CENTER_ALIGNED,";
  protected final String TEXT_15 = NL + "  " + NL + "  .kPassiveState0= ";
  protected final String TEXT_16 = "U," + NL + "  .kPassiveState1= ";
  protected final String TEXT_17 = "U," + NL + "  .kPassiveLevel0= ";
  protected final String TEXT_18 = "U," + NL + "  .kPassiveLevel1= ";
  protected final String TEXT_19 = "U," + NL + "  " + NL + "  .kExtStartTrig= ";
  protected final String TEXT_20 = " 0U, ";
  protected final String TEXT_21 = " 1U, ";
  protected final String TEXT_22 = NL + "  .kExtStopTrig= ";
  protected final String TEXT_23 = " 0U, ";
  protected final String TEXT_24 = " 1U, ";
  protected final String TEXT_25 = NL + "  .kStartEdge=  CCU8PWMLIB_NOTRIGGER,";
  protected final String TEXT_26 = NL + "  .kStartEdge=  CCU8PWMLIB_RISINGEDGE,";
  protected final String TEXT_27 = NL + "  .kStartEdge=  CCU8PWMLIB_FALLINGEDGE,";
  protected final String TEXT_28 = NL + "  .kStartEdge=  CCU8PWMLIB_BOTHEDGES,";
  protected final String TEXT_29 = NL + "  .kStopEdge=  CCU8PWMLIB_NOTRIGGER,";
  protected final String TEXT_30 = NL + "  .kStopEdge=  CCU8PWMLIB_RISINGEDGE,";
  protected final String TEXT_31 = NL + "  .kStopEdge=  CCU8PWMLIB_FALLINGEDGE,";
  protected final String TEXT_32 = NL + "  .kStopEdge=  CCU8PWMLIB_BOTHEDGES,";
  protected final String TEXT_33 = "  ";
  protected final String TEXT_34 = NL + "  .ExtStartConfig=  CCU8PWMLIB_START_TIMER,";
  protected final String TEXT_35 = NL + "  .ExtStartConfig=  CCU8PWMLIB_CLEAR_START_TIMER,";
  protected final String TEXT_36 = "  ";
  protected final String TEXT_37 = NL + "  .ExtStopConfig=  CCU8PWMLIB_STOP_TIMER,";
  protected final String TEXT_38 = NL + "  .ExtStopConfig=  CCU8PWMLIB_CLEAR_TIMER,";
  protected final String TEXT_39 = "  " + NL + "  .ExtStopConfig=  CCU8PWMLIB_CLEAR_STOP_TIMER,";
  protected final String TEXT_40 = "  " + NL + "" + NL + "  .kTrapEnable= ";
  protected final String TEXT_41 = "U," + NL + "  .kTrapSync= ";
  protected final String TEXT_42 = "U," + NL + "  .kTrapExitControl= ";
  protected final String TEXT_43 = "U," + NL + "  .kTrapLevel= ";
  protected final String TEXT_44 = "U," + NL + "  " + NL + "  .kResolution = (float)";
  protected final String TEXT_45 = "," + NL + "  .kCCUPrescalar= ";
  protected final String TEXT_46 = "U," + NL + "  .kTimerConcatenation= ";
  protected final String TEXT_47 = "U," + NL + "   /*During timer concatenation, compare values are taken from UI where lower 16-bit " + NL + "   is loaded into the lower timer and higer 16-bit to higher timer.*/" + NL + "  .kCompareValue1= ";
  protected final String TEXT_48 = "U," + NL + "  .kCompareValue2 = ";
  protected final String TEXT_49 = "U," + NL + "  .kPeriodVal= ";
  protected final String TEXT_50 = "U," + NL + "  " + NL + "  .kFallingDeadTime = ";
  protected final String TEXT_51 = "U," + NL + "  .kRisingDeadTime= ";
  protected final String TEXT_52 = "U," + NL + "  .kDeadTimePrescalar= ";
  protected final String TEXT_53 = "U," + NL + "  .DeadTimeConf= ";
  protected final String TEXT_54 = " CCU8PWMLIB_DISABLE, ";
  protected final String TEXT_55 = " CCU8PWMLIB_ENABLEDIRECTOUTPUT, ";
  protected final String TEXT_56 = " CCU8PWMLIB_ENABLEINVERTEDOUTPUT, ";
  protected final String TEXT_57 = " CCU8PWMLIB_ENABLE, ";
  protected final String TEXT_58 = NL + "  " + NL + "  .kDitherSetting= ";
  protected final String TEXT_59 = "U," + NL + "  .kDitherCompare = ";
  protected final String TEXT_60 = "U," + NL + "" + NL + "  .ShadowTransfer= ";
  protected final String TEXT_61 = "U," + NL + "  .ShadowTransferMask= ";
  protected final String TEXT_62 = NL + "  ";
  protected final String TEXT_63 = "U,";
  protected final String TEXT_64 = " 0x01U, ";
  protected final String TEXT_65 = " 0x01U,";
  protected final String TEXT_66 = " 0x10U, ";
  protected final String TEXT_67 = " 0x11U,";
  protected final String TEXT_68 = " 0x100U, ";
  protected final String TEXT_69 = " 0x110U,";
  protected final String TEXT_70 = " 0x1000U, ";
  protected final String TEXT_71 = " 0x1100U,";
  protected final String TEXT_72 = "  " + NL + "  .Start= ";
  protected final String TEXT_73 = "U," + NL + "  .StartMask= ";
  protected final String TEXT_74 = NL + "  ";
  protected final String TEXT_75 = "U,";
  protected final String TEXT_76 = " 0x01U, ";
  protected final String TEXT_77 = " 0x01U,";
  protected final String TEXT_78 = " 0x2U, ";
  protected final String TEXT_79 = " 0x3U,";
  protected final String TEXT_80 = " 0x4U, ";
  protected final String TEXT_81 = " 0x6U,";
  protected final String TEXT_82 = " 0x8U, ";
  protected final String TEXT_83 = " 0xCU,";
  protected final String TEXT_84 = "  " + NL + "  " + NL + "  .FirstSlice= ";
  protected final String TEXT_85 = " CCU8PWMLIB_SLICE";
  protected final String TEXT_86 = " ";
  protected final String TEXT_87 = " CCU8PWMLIB_SLICE";
  protected final String TEXT_88 = "," + NL + "  .SecondSlice= CCU8PWMLIB_SLICE";
  protected final String TEXT_89 = "," + NL + "  .CC8yKernRegsPtr= (CCU8_GLOBAL_TypeDef*) CCU8";
  protected final String TEXT_90 = "_BASE," + NL + "  .CC8yRegsPtr= ";
  protected final String TEXT_91 = "CCU8";
  protected final String TEXT_92 = "_CC8";
  protected final String TEXT_93 = ",";
  protected final String TEXT_94 = " CCU8";
  protected final String TEXT_95 = "_CC8";
  protected final String TEXT_96 = ",";
  protected final String TEXT_97 = NL + "  .CC8yRegs1Ptr= CCU8";
  protected final String TEXT_98 = "_CC8";
  protected final String TEXT_99 = "," + NL + "  .DynamicHandleType= &PWMSP002_DynamicHandle";
  protected final String TEXT_100 = "," + NL + "  .StartControl = ";
  protected final String TEXT_101 = "U," + NL + "  .InterruptControl = 0x";
  protected final String TEXT_102 = "U," + NL + "  .SetCompareFuncPtr = &";
  protected final String TEXT_103 = "," + NL + "  .SetDutyFuncPtr = &";
  protected final String TEXT_104 = "," + NL + "};";
  protected final String TEXT_105 = NL + "//This app is not mapped to any CCU8 slice.";
  protected final String TEXT_106 = NL + "/*CODE_BLOCK_END*/";
  protected final String TEXT_107 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     App2JetInterface app = (App2JetInterface) argument; 
    stringBuffer.append(TEXT_1);
     String AppBaseuri = "app/pwmsp002/"; 
    stringBuffer.append(TEXT_2);
    stringBuffer.append(app.getAppVersion(AppBaseuri));
    stringBuffer.append(TEXT_3);
     String SliceUri = null; 
     String Slice1Uri = null; 
     String kernelNo = null; 
     String sliceNo = null; 
     String slice1No = null; 
     String zero = "0"; 
    stringBuffer.append(TEXT_4);
     String one = "1"; 
    stringBuffer.append(TEXT_5);
     String two = "2"; 
    stringBuffer.append(TEXT_6);
     String three = "3"; 
     String appInst  = null; 
     ArrayList<String> appsList = (ArrayList<String>)(app.getApps("app/pwmsp002/"));
for (String appIns : appsList ) {
appInst = appIns.substring(appIns.lastIndexOf("/")+1);
     SliceUri = app.getMappedUri(AppBaseuri + appInst +"/slice"); 
     if ((SliceUri != null) && (SliceUri.trim() != "")) { 
     kernelNo = SliceUri.substring(SliceUri.indexOf("/ccu8")+6,SliceUri.indexOf("/cc8/")); 
     sliceNo = SliceUri.substring(SliceUri.length() -1); 
     Slice1Uri = app.getMappedUri(AppBaseuri + appInst +"/slice1"); 
     if ((Slice1Uri != null) && (Slice1Uri.trim() != "")) { 
     slice1No = Slice1Uri.substring(Slice1Uri.length() -1); 
    }else{ slice1No = "0"; }
     int interrupt = (app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_erwcomaprematch/0") << 2) | app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_erwperiodmatch/0") 
|(app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_erwextstop/0") << 9) |(app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_erwtrap/0") << 10)
|(app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_erwextstart/0") << 8);
     String SetDutyCycle = null;
String SetCompare = null;
int countingmode = app.getIntegerValue(AppBaseuri + appInst + "/slice/tc/tcm");
int comparemode = app.getIntegerValue(AppBaseuri + appInst + "/slice/chc/ase");
int timerconcat =  app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irtimerconcat");
int period_val = app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_irSelPeriodReg");
int duty_val = app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_irwDutyCycle");
int compreg_val1 = app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_irCompareVal1");

if(period_val > 65535 && timerconcat == 1)
{
  period_val = (app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irperiodregval1") << 16) | (app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irperiodregval0"));
  compreg_val1 = (app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_ircompare1regval1") << 16 ) | app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_ircompare1regval0");
}
if(countingmode == 0 && comparemode == 0 && timerconcat == 0){
  SetDutyCycle = "CCU8PWMLIB_SetDutyEdgeAlignSymmetric";
  SetCompare = "CCU8PWMLIB_SetCompareSymmetric";
}
else if(countingmode == 0 && comparemode == 0 && timerconcat == 1 ){
  SetDutyCycle = "CCU8PWMLIB_SetDutyEdgeAlignSymmetricTimerConcat";
  SetCompare = "CCU8PWMLIB_SetCompareEdgeAlignSymmetricTimerConcat";
}
else if (countingmode == 0 && comparemode == 1){
  SetDutyCycle = "CCU8PWMLIB_SetDutyEdgeAlignAsymmetric";
  SetCompare = "CCU8PWMLIB_SetCompareAsymmetric"; 
}
else if (countingmode == 1 && comparemode == 0){
  SetDutyCycle = "CCU8PWMLIB_SetDutyCenterAlignSymmetric";
  SetCompare = "CCU8PWMLIB_SetCompareSymmetric"; 
}
else if (countingmode == 1 && comparemode == 1){
  SetDutyCycle = "CCU8PWMLIB_SetDutyCenterAlignAsymmetric";
  SetCompare = "CCU8PWMLIB_SetCompareAsymmetric"; 
}

    DecimalFormat df = new DecimalFormat("0.000");
    stringBuffer.append(TEXT_7);
    stringBuffer.append( appInst);
    stringBuffer.append(TEXT_8);
    stringBuffer.append( appInst);
    stringBuffer.append(TEXT_9);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/slice/tc/tssm"));
    stringBuffer.append(TEXT_10);
    if(app.getIntegerValue(AppBaseuri + appInst + "/slice/chc/ase")==0) { 
    stringBuffer.append(TEXT_11);
     } else  { 
    stringBuffer.append(TEXT_12);
     } 
    if(app.getIntegerValue(AppBaseuri + appInst + "/slice/tc/tcm")==0) { 
    stringBuffer.append(TEXT_13);
     } else  { 
    stringBuffer.append(TEXT_14);
     } 
    stringBuffer.append(TEXT_15);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/slice/chc/ocs1") );
    stringBuffer.append(TEXT_16);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/slice/chc/ocs2") );
    stringBuffer.append(TEXT_17);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/slice/psl/psl11") );
    stringBuffer.append(TEXT_18);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/slice/psl/psl12") );
    stringBuffer.append(TEXT_19);
    if(app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_erwStartEdge/0") ==1){
    stringBuffer.append(TEXT_20);
    }else{
    stringBuffer.append(TEXT_21);
    }
    stringBuffer.append(TEXT_22);
    if(app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_erwStopEdge/0") == 1){
    stringBuffer.append(TEXT_23);
    }else{
    stringBuffer.append(TEXT_24);
    }
    if(app.getIntegerValue(AppBaseuri + appInst + "/slice/ins/ev0em")==0) {
    stringBuffer.append(TEXT_25);
     } else if(app.getIntegerValue(AppBaseuri + appInst + "/slice/ins/ev0em")==1) { 
    stringBuffer.append(TEXT_26);
     } else if(app.getIntegerValue(AppBaseuri + appInst + "/slice/ins/ev0em")==2) { 
    stringBuffer.append(TEXT_27);
     } else { 
    stringBuffer.append(TEXT_28);
     } 
    if(app.getIntegerValue(AppBaseuri + appInst + "/slice/ins/ev1em")==0) {
    stringBuffer.append(TEXT_29);
     } else if(app.getIntegerValue(AppBaseuri + appInst + "/slice/ins/ev1em")==1) { 
    stringBuffer.append(TEXT_30);
     } else if(app.getIntegerValue(AppBaseuri + appInst + "/slice/ins/ev1em")==2) { 
    stringBuffer.append(TEXT_31);
     } else { 
    stringBuffer.append(TEXT_32);
     } 
    stringBuffer.append(TEXT_33);
    if(app.getIntegerValue(AppBaseuri + appInst + "/slice/tc/strm")==0) {
    stringBuffer.append(TEXT_34);
     } else { 
    stringBuffer.append(TEXT_35);
     } 
    stringBuffer.append(TEXT_36);
    if(app.getIntegerValue(AppBaseuri + appInst + "/slice/tc/endm")==0) {
    stringBuffer.append(TEXT_37);
     } else if(app.getIntegerValue(AppBaseuri + appInst + "/slice/tc/endm")==1) { 
    stringBuffer.append(TEXT_38);
     } else { 
    stringBuffer.append(TEXT_39);
     } 
    stringBuffer.append(TEXT_40);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_erwenabletrap/0") );
    stringBuffer.append(TEXT_41);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_erwtrapexittime/0") );
    stringBuffer.append(TEXT_42);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/slice/tc/trpsw") );
    stringBuffer.append(TEXT_43);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/slice/ins/ev2lm") );
    stringBuffer.append(TEXT_44);
    stringBuffer.append( app.getFormattedDoubleValue((AppBaseuri + appInst + "/PWMSP002_irSelResolution"),"0.000"));
    stringBuffer.append(TEXT_45);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_irSelprescalar") );
    stringBuffer.append(TEXT_46);
    stringBuffer.append( timerconcat);
    stringBuffer.append(TEXT_47);
    stringBuffer.append( compreg_val1);
    stringBuffer.append(TEXT_48);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_irCompareVal2")  );
    stringBuffer.append(TEXT_49);
    stringBuffer.append( period_val);
    stringBuffer.append(TEXT_50);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_irwselFallDeadTimereg"));
    stringBuffer.append(TEXT_51);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_irwselRiseDeadTimereg"));
    stringBuffer.append(TEXT_52);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_irseldeadtimeprescalar"));
    stringBuffer.append(TEXT_53);
    if(app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_erwDeadTimeConf/0") ==1){
    stringBuffer.append(TEXT_54);
    }
  else if(app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_erwDeadTimeConf/1") ==1 ){
    stringBuffer.append(TEXT_55);
    }
  else if(app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_erwDeadTimeConf/2") ==1 ){
    stringBuffer.append(TEXT_56);
    }
  else if(app.getIntegerValue(AppBaseuri + appInst + "/PWMSP002_erwDeadTimeConf/3") ==1 ){
    stringBuffer.append(TEXT_57);
    }
  
    stringBuffer.append(TEXT_58);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/slice/tc/dithe"));
    stringBuffer.append(TEXT_59);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/slice/dits/dcvs"));
    stringBuffer.append(TEXT_60);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irwshadowtransfer"));
    stringBuffer.append(TEXT_61);
    if(app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irwtoplevelapp") == 1){
    stringBuffer.append(TEXT_62);
    stringBuffer.append(app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irwshadowtransfermask") );
    stringBuffer.append(TEXT_63);
    }else {
  if(sliceNo.equals(zero)){
  if (app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irtimerconcat") == 0){ 
    stringBuffer.append(TEXT_64);
    }
  else {
    stringBuffer.append(TEXT_65);
    }
  } 
  else if(sliceNo.equals(one)){
   if (app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irtimerconcat") == 0){ 
    stringBuffer.append(TEXT_66);
    }
   else { 
    stringBuffer.append(TEXT_67);
    }
  }  
  else if(sliceNo.equals(two) ){
  if (app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irtimerconcat") == 0){ 
    stringBuffer.append(TEXT_68);
    }
  else { 
    stringBuffer.append(TEXT_69);
    }
  }  
  else if(sliceNo.equals(three)){
  if (app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irtimerconcat") == 0){ 
    stringBuffer.append(TEXT_70);
    }
  else { 
    stringBuffer.append(TEXT_71);
    }
  }  
  }
    stringBuffer.append(TEXT_72);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irwstart"));
    stringBuffer.append(TEXT_73);
    if(app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irwtoplevelapp") == 1){
    stringBuffer.append(TEXT_74);
    stringBuffer.append( app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irwshadowtransfermask"));
    stringBuffer.append(TEXT_75);
    }else {
    if(sliceNo.equals(zero)){
      if (app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irtimerconcat") == 0){ 
    stringBuffer.append(TEXT_76);
    }
      else {
    stringBuffer.append(TEXT_77);
    }
    } 
    else if(sliceNo.equals(one)){
       if (app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irtimerconcat") == 0){ 
    stringBuffer.append(TEXT_78);
    }
       else { 
    stringBuffer.append(TEXT_79);
    }
    }  
    else if(sliceNo.equals(two) ){
      if (app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irtimerconcat") == 0){ 
    stringBuffer.append(TEXT_80);
    }
      else { 
    stringBuffer.append(TEXT_81);
    }
    }  
    else if(sliceNo.equals(three)){
      if (app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_irtimerconcat") == 0){ 
    stringBuffer.append(TEXT_82);
    }
      else { 
    stringBuffer.append(TEXT_83);
    }
    }  
  }
    stringBuffer.append(TEXT_84);
     if(timerconcat == 0){
    stringBuffer.append(TEXT_85);
    stringBuffer.append(sliceNo);
    stringBuffer.append(TEXT_86);
    } else if(timerconcat == 1){ 
    stringBuffer.append(TEXT_87);
    stringBuffer.append(slice1No);
    } 
    stringBuffer.append(TEXT_88);
    stringBuffer.append(sliceNo);
    stringBuffer.append(TEXT_89);
    stringBuffer.append( kernelNo);
    stringBuffer.append(TEXT_90);
     if(timerconcat == 0){
    stringBuffer.append(TEXT_91);
    stringBuffer.append( kernelNo);
    stringBuffer.append(TEXT_92);
    stringBuffer.append(sliceNo);
    stringBuffer.append(TEXT_93);
    } else if(timerconcat == 1){ 
    stringBuffer.append(TEXT_94);
    stringBuffer.append( kernelNo);
    stringBuffer.append(TEXT_95);
    stringBuffer.append(slice1No);
    stringBuffer.append(TEXT_96);
    } 
    stringBuffer.append(TEXT_97);
    stringBuffer.append( kernelNo);
    stringBuffer.append(TEXT_98);
    stringBuffer.append(sliceNo);
    stringBuffer.append(TEXT_99);
    stringBuffer.append( appInst);
    stringBuffer.append(TEXT_100);
    stringBuffer.append(app.getIntegerValue(AppBaseuri + appInst + "/pwmsp002_erwstart/0"));
    stringBuffer.append(TEXT_101);
    stringBuffer.append( Integer.toHexString(interrupt) );
    stringBuffer.append(TEXT_102);
    stringBuffer.append( SetCompare);
    stringBuffer.append(TEXT_103);
    stringBuffer.append( SetDutyCycle);
    stringBuffer.append(TEXT_104);
    }else {
    stringBuffer.append(TEXT_105);
    }}
    stringBuffer.append(TEXT_106);
    stringBuffer.append(TEXT_107);
    return stringBuffer.toString();
  }
}
