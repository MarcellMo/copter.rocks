/*
 * main.c
 *
 *  Created on: 2016 Sep 15 08:41:08
 *  Author: wielandd
 */




#include <DAVE.h>                 //Declarations from DAVE Code Generation (includes SFR declaration)
#include "_HAL/GPIO.h"
#include "_HAL/Delay/util.h"


void setup(void);
/**

 * @brief main() - Application entry point
 *
 * <b>Details of function</b><br>
 * This routine is the application entry point. It is invoked by the device startup code. It is responsible for
 * invoking the APP initialization dispatcher routine - DAVE_Init() and hosting the place-holder for user application
 * code.
 */

int main(void)
{

  setup();
  delay(10000u);
  PWM_CCU4_SetDutyCycle(&PWM_OUTPUT_1,4500u);
  PWM_CCU4_SetDutyCycle(&PWM_OUTPUT_2,4500u);
  PWM_CCU4_SetDutyCycle(&PWM_OUTPUT_3,4500u);
  PWM_CCU4_SetDutyCycle(&PWM_OUTPUT_4,4500u);
  Set(P3_0);

  /* Placeholder for user application code. The while loop below can be replaced with user application code. */
  while(1U);
}

void setup(void)
{
	DAVE_STATUS_t status;

	status = DAVE_Init();           /* Initialization of DAVE APPs  */

	if(status == DAVE_STATUS_FAILURE)
	{
		/* Placeholder for error handler code. The while loop below can be replaced with an user error handler. */
		XMC_DEBUG("DAVE APPs initialization failed\n");

		while(1U)
		{

		}
	}
	Control_P0_9(OUTPUT_PP_GP, VERYSTRONG);	//Configure Pin 0.9
	Control_P3_0(OUTPUT_PP_GP, VERYSTRONG);	//Configure Pin 3.0
	Control_P3_1(OUTPUT_PP_GP, VERYSTRONG); //Configure Pin 3.1
	Control_P3_2(OUTPUT_PP_GP, VERYSTRONG); //Configure Pin 3.2

	PWM_CCU4_SetDutyCycle(&PWM_OUTPUT_1,9000u);
	PWM_CCU4_SetDutyCycle(&PWM_OUTPUT_2,9000u);
	PWM_CCU4_SetDutyCycle(&PWM_OUTPUT_3,9000u);
	PWM_CCU4_SetDutyCycle(&PWM_OUTPUT_4,9000u);

	PWM_CCU4_Start(&PWM_OUTPUT_1);
	PWM_CCU4_Start(&PWM_OUTPUT_2);
	PWM_CCU4_Start(&PWM_OUTPUT_3);
	PWM_CCU4_Start(&PWM_OUTPUT_4);

	Set(P3_2);
}

